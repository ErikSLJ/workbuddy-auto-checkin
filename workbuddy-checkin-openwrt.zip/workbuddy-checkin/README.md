# WorkBuddy 自动签到机器人 · OpenWrt 软路由挂机版（share 分享包）

> 把 WorkBuddy 的每日签到交给家里的软路由，**电脑关机也能签**，
> 成功/失败都会推送到你的微信。一次部署，长期自动。

---

## 目录

1. [这个工具是干什么的](#一这个工具是干什么的)
2. [你需要准备什么](#二你需要准备什么)
3. [部署总览（先看一眼心里有数）](#三部署总览)
4. [第 1 步：配置 SSH 免密登录](#四第-1-步配置-ssh-免密登录)
5. [第 2 步：把文件传到路由器并运行部署](#五第-2-步把文件传到路由器并运行部署)
6. [第 3 步：导出你自己的签到令牌（最关键）](#六第-3-步导出你自己的签到令牌最关键)
7. [第 4 步：配置微信推送（强烈建议）](#七第-4-步配置微信推送)
8. [怎么改签到时间](#八怎么改签到时间)
9. [日常怎么查看状态](#九日常怎么查看状态)
10. [出问题了怎么办（排障手册）](#十出问题了怎么办)
11. [安全须知（必读）](#十一安全须知必读)
12. [文件清单](#十二文件清单)

---

## 一、这个工具是干什么的

WorkBuddy 每天签到能领积分，但人总有忘记的时候。这个工具做的事：

- 在你家的 **OpenWrt 软路由**上装一套 Python 小脚本
- 路由器的定时器（cron）**每天早上自动**帮你签到
- 签到结果通过 **方糖（Server酱）** 推送到你微信：成功一条、失败也一条
- 电脑开不开机都无所谓，路由器 7×24 在线

它**不需要**你的账号密码——用的是你自己从客户端导出的一枚"长效通行证"（令牌），
令牌只放在你自己的路由器上，权限 600，只有 root 能读。

---

## 二、你需要准备什么

| 序号 | 需要的东西 | 说明 |
|---|---|---|
| 1 | 一台 OpenWrt 软路由 | 能登录管理页（LuCI），你知道 root 密码。x86 / arm 都行 |
| 2 | 一台 Windows 电脑 | 装了 WorkBuddy 客户端，并且**已经登录**你的账号 |
| 3 | 电脑上有 Python 3.6 以上 | 导出令牌那一步要用（第 3 步会教你怎么装） |
| 4 | 一个方糖（Server酱）账号 | 免费注册，用来收微信推送（第 4 步会教） |

> **不确定路由器是不是 OpenWrt？** 浏览器打开路由器管理页（一般是
> `http://192.168.1.1`），如果页面左上角写着 OpenWrt / LuCI，就是了。

---

## 三、部署总览（先看一眼心里有数）

### 🚀 懒人通道：让 WorkBuddy 替你部署（推荐）

本包里有个文件：**《一键部署-把这段话粘贴给WorkBuddy.txt》**。

用法：把那个 txt 里的指定段落复制，粘贴到 WorkBuddy 对话框发送，
AI 就会接管整个部署——探测环境、生成密钥、传文件、验证、配定时任务，
全程帮你做。**你不需要把路由器密码发给它**，密码只在你自己的终端里输；
它每一步都会先问你、汇报进度。

适合：不想看教程、想让 AI 包办的人。遇到 AI 卡住时，再回到本
README 手动操作对应的步骤即可。

### 🔧 手动通道：照本 README 一步步做

整个过程一共 4 步，大约 20 分钟：

```
第 1 步  配 SSH 免密登录（以后电脑连路由器不用输密码）   ~10 分钟
第 2 步  把文件传上去，跑一键部署脚本                    ~3 分钟
第 3 步  导出你自己的令牌传给路由器（核心步骤）           ~5 分钟
第 4 步  注册方糖，配置微信推送                          ~3 分钟
```

每一步都给了可以直接复制的命令。**复制命令时整行复制，一行一行来**，
不要一次粘好几行。

---

## 四、第 1 步：配置 SSH 免密登录

### 什么是 SSH？

SSH 就是"从你的电脑远程操作路由器的命令行"。OpenWrt 没有桌面，
所有操作都在命令行里完成。配好"免密登录"后，电脑连路由器就不用每次输密码。

### 1.0 先确认你的路由器固件类型（很关键）

这一步"该用哪种钥匙"**不看你电脑，只看路由器上的 OpenWrt 固件版本**。
OpenWrt 用的 SSH 服务端叫 `Dropbear`，它对"客户端钥匙"的接受规则随固件
年代不同而不一样——

| 路由器固件情况 | 只认哪种钥匙 | 怎么判断 |
|---|---|---|
| **新固件**：OpenWrt 24.x / 2024 以后常见编译版（内核 6.x，例如 eSir 2026 版） | **ed25519** | LuCI 底部版本号含 24.x；或 `uname -a` 内核显示 6.x |
| **老固件**：OpenWrt 21.x / 2023 及更早常见编译版（内核 5.x 及以下） | **RSA 2048** | 版本号 21.x 或更低；或 `uname -a` 内核 5.x 及以下 |

> **为什么会这样？** 老 Dropbear 只接受 RSA 签名，ed25519 公钥会被无视；
> 新 Dropbear 反过来**拒绝 RSA 客户端钥匙**，只认 ed25519。钥匙类型选错，
> 就会一直 `Permission denied`（正是本工具早期踩过的坑，所以才要你先确认）。

**最省心的做法（推荐新手）：** 直接按下面 1.1 生成 **ed25519** 钥匙；
到 1.3 测试时如果**还是要密码 / 报 `Permission denied`**，说明你是老固件，
回头把 1.1 的命令换成 `ssh-keygen -t rsa -b 2048 -f "...openwrt_rsa" -N '""'`、
1.2 改用 `openwrt_rsa.pub` 即可。

### 1.1 生成一把"钥匙"

按键盘上的 `Win` 键，直接输入 `powershell`，回车，打开一个蓝底窗口。
在窗口里粘贴这行（鼠标右键粘贴），回车：

```powershell
ssh-keygen -t ed25519 -f "$env:USERPROFILE\.ssh\openwrt_ed25519" -N '""'
```

- 中途问你要不要覆盖（`Overwrite (y/n)?`）就输 `y` 回车
- 最后会显示一把钥匙的"指纹图案"，说明生成成功

> 第一次用 ssh 的话，这行命令会自动创建 `.ssh` 文件夹，不用手动建。

### 1.2 把"钥匙"装进路由器

仍然在 PowerShell 里，执行（**把 `192.168.1.1` 换成你路由器的实际 IP**）：

```powershell
type $env:USERPROFILE\.ssh\openwrt_ed25519.pub | ssh root@192.168.1.1 "mkdir -p /etc/dropbear && cat >> /etc/dropbear/authorized_keys && chmod 700 /etc/dropbear && chmod 600 /etc/dropbear/authorized_keys"
```

- 第一次连接会问 `Are you sure you want to continue connecting (yes/no)?`
  输 `yes` 回车
- 然后提示输密码：**输密码时屏幕上什么都不显示，连星号都没有，
  这是正常的**，盲打完整密码回车即可

### 1.3 测试免密是否生效

```powershell
ssh root@192.168.1.1 "echo 免密成功"
```

- 如果直接输出 `免密成功`（没要密码）→ ✅ 第 1 步完成
- 如果还是要密码 → 上面 1.2 的命令没执行成功，重做一遍；
  还不行见[排障手册](#十出问题了怎么办)

---

## 五、第 2 步：把文件传到路由器并运行部署

### 2.1 解压本包

把收到的 zip 解压到一个**路径简单**的地方，推荐 `D:\wb-checkin`。
解压后里面有个 `workbuddy-checkin` 文件夹，里面是各种脚本。

### 2.2 上传文件

在 PowerShell 里（假设你解压到了 `D:\wb-checkin`）：

```powershell
cd D:\wb-checkin\workbuddy-checkin
ssh root@192.168.1.1 "mkdir -p /tmp/wb-deploy"
scp .\* root@192.168.1.1:/tmp/wb-deploy/
```

最后一条命令会刷出一串 `100%`，全部走完就是传完了。

### 2.3 运行一键部署

```powershell
ssh root@192.168.1.1 "sh /tmp/wb-deploy/deploy_v2.sh"
```

脚本会自动做这些事，**全程你只需要看输出**：

1. 检查路由器上有没有 Python、ssl 模块、CA 证书（缺啥装啥）
2. 实测能不能连通签到服务器
3. 把脚本安装到路由器的 `/root/.workbuddy/` 目录
4. 写入每天 9:00 的定时任务
5. 做一次**只读验证**（只查状态，不会真的签到、不会消耗推送条数）

看到最后打印"完成"和路径一览就是部署成功了。
**此时先别急，令牌还没导，签到还跑不起来**——继续第 3 步。

> 部署中途如果卡在 `opkg update` 或报网络错误，多半是路由器软件源连不上，
> 把最后 20 行输出发给分享给你这个工具的人（或发到交流群）求助。

---

## 六、第 3 步：导出你自己的签到令牌（最关键）

> **为什么每个人都要自己导？** 令牌等于你账号的"通行证"，跟账号走、
> 不跟电脑走。你的令牌只能证明你的身份，别人拿不到也用不了你的。

### 3.1 电脑上装 Python（已经装过的跳过）

打开 https://www.python.org/downloads/ 点黄色大按钮下载，
安装时**务必勾选底部的 `Add Python to PATH`**，再点 Install Now。
装完把 PowerShell 关掉重开一次。

### 3.2 装一个解密小工具

PowerShell 里执行：

```powershell
pip install pycryptodome
```

### 3.3 导出令牌

确认电脑上的 WorkBuddy 客户端**已经登录**，然后在**解压出来的
`workbuddy-checkin` 文件夹里**打开 PowerShell（在该文件夹的地址栏输入
`powershell` 回车，就会在这个目录打开），执行：

```powershell
python rt_auth.py --export-rt --save
```

成功的话会提示令牌已保存到 `C:\Users\你的用户名\.workbuddy\checkin-rt.json`。

### 3.4 传到路由器并验证

```powershell
scp $env:USERPROFILE\.workbuddy\checkin-rt.json root@192.168.1.1:/root/.workbuddy/
ssh root@192.168.1.1 "chmod 600 /root/.workbuddy/checkin-rt.json && cd /root/.workbuddy/scripts && python3 rt_auth.py --check --no-notify"
```

看到输出里有 `"status": "ok"` 和积分余额 → ✅ 全部打通！
从明天早上 9 点开始，路由器会自动签到。

---

## 七、第 4 步：配置微信推送

不配置也能签到，但**失败了没人告诉你**，所以强烈建议配。

### 4.1 注册方糖拿 SendKey

1. 浏览器打开 **👉 [点这里注册方糖 Server酱](https://sct.ftqq.com/r/28382)**
   （通过这个邀请链接注册，是对打包分享者的**支持**；你付的费用
   一分不多，免费版照样每天 5 条推送）
2. 微信扫码登录
3. 点「SendData」→「Key」页，复制那串以 `SCT` 开头的 SendKey
4. 按提示用微信关注「方糖」服务号并绑定（不绑收不到消息）

### 4.2 填进路由器

```powershell
ssh root@192.168.1.1 "vi /root/.workbuddy/scripts/notify_config.json"
```

vi 操作小白版：按键盘 `i` 进入编辑 → 找到 `把这里替换成你自己的SendKey`
那一段，删掉换成你的 SCT 开头的 Key → 按 `Esc` → 输入 `:wq` 回车保存退出。

> 怕 vi 手抖的话，也可以先在电脑上用记事本改好包里的
> `notify_config.json`（第 3.3 步导令牌之前改），再按第 2.2 步重新 scp 一遍。

### 4.3 测试推送

```powershell
ssh root@192.168.1.1 "cd /root/.workbuddy/scripts && python3 push_message.py --test 部署成功"
```

你微信收到消息 → ✅ 大功告成。

> 方糖免费版每天 5 条推送，签到每天最多用 2 条（成功/失败），够用。

---

## 八、怎么改签到时间

默认每天早上 9:00。假设想改成 8:30：

```powershell
ssh root@192.168.1.1 "crontab -l > /tmp/c && sed -i 's/0 9 \* \* \*/30 8 * * */' /tmp/c && crontab /tmp/c && crontab -l"
```

规律就是 `分 时 日 月 周`，`30 8` 就是 8 点 30 分。

> 注意：OpenWrt 默认时区可能是 UTC（比北京时间慢 8 小时）。
> 部署脚本运行时会打印当前时区；如果显示 UTC，9 点实际是北京时间下午 5 点。
> 在 LuCI「系统 → 系统设置」把时区改成 `Asia/Shanghai` 即可。

---

## 九、日常怎么查看状态

**方式一（最省事）：** 收微信推送。每天 9 点过后收到"签到成功"就是一切正常。

**方式二：** 浏览器登录路由器管理页 → 「系统」→「计划任务」，
能看到签到那一行就说明任务还在。

**方式三（命令行）：**

```powershell
ssh root@192.168.1.1 "tail -n 20 /root/.workbuddy/scripts/checkin.log"   # 最近日志
ssh root@192.168.1.1 "crontab -l"                                        # 定时任务
```

---

## 十、出问题了怎么办

| 现象 | 原因与处理 |
|---|---|
| 免密登录配不上，一直要密码 | ① 确认用的是 **ed25519** 公钥（本教程生成的就是 `openwrt_ed25519.pub`）；② 路由器把公钥写错了位置，手动执行：`type $env:USERPROFILE\.ssh\openwrt_ed25519.pub \| ssh root@IP "cat >> /etc/dropbear/authorized_keys && chmod 600 /etc/dropbear/authorized_keys"` |
| ssh 连路由器报 `Bad permissions` | Windows 的 OpenSSH 要求私钥文件权限不能太开放：管理员 PowerShell 执行 `icacls "$env:USERPROFILE\.ssh\openwrt_ed25519" /inheritance:r /grant:r "$env:USERNAME:F"`，再重试 |
| 部署脚本报 `python3-ssl` 相关 | SSH 进路由器执行 `opkg update && opkg install python3-ssl`，然后重跑部署脚本 |
| 推送收不到但签到正常 | 方糖的「方糖」服务号没关注/被折叠了，去公众号列表翻一下；SendKey 填错也会这样 |
| 某天收到"签到失败"推送 | 十有八九是令牌被客户端续期顶掉了：客户端重新登录一次，重做第 3 步即可（几个月一次的量级） |
| 客户端突然要求重新登录 | 正常现象（见上条），登录即可，不影响路由器 |
| 想彻底停用 | `ssh root@IP "crontab -l \| grep -v auto_checkin \| crontab -"` 删掉定时任务；`rm -rf /root/.workbuddy` 删掉全部文件 |

---

## 十一、安全须知（必读）

1. **`checkin-rt.json` 等于你的账号钥匙**——永远不要发给任何人、
   不要截图、不要上传网盘。
2. **真实的 `notify_config.json`（填了自己 SendKey 的）** 不要外发，
   别人拿到能冒充你推消息。
3. 电脑上用于导出令牌的那份 `~/.workbuddy/checkin-rt.json`，导完传上去后可以删。
4. 本分享包里的脚本**不包含任何人的令牌和密钥**，可以放心转发。

---

## 十二、文件清单

| 文件 | 作用 |
|---|---|
| auto_checkin.py | 签到总指挥（cron 每天调它） |
| rt_auth.py | 长效令牌：导出 / 刷新 / 查询 |
| workbuddy_checkin.py | 客户端本地通道（备用） |
| web_auth.py | 网页 Cookie 通道（备用） |
| push_message.py | 推送模块（方糖 / 钉钉 / 飞书 / bark 等） |
| cookie_keep.py | Cookie 凭据看门狗（备用） |
| deploy_v2.sh | 一键部署脚本 |
| notify_config.json | 推送配置模板（记得填你自己的 SendKey） |
| 一键部署-把这段话粘贴给WorkBuddy.txt | 懒人通道：粘给 WorkBuddy，让 AI 替你部署 |

---

*祝挂机愉快。部署卡住了就带着报错截图来问。*
