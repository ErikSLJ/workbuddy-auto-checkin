# WorkBuddy 自动签到机器人 · OpenWrt 软路由挂机版

> 把每日签到交给家里的软路由，**电脑关机也能签**。
> 两个账号各跑各的，全部跑完后合并成**一条微信汇总**，每个账号单独一行。
> 一次部署，长期自动。

---

## 目录

1. [这个工具是干什么的](#一这个工具是干什么的)
2. [你需要准备什么](#二你需要准备什么)
3. [部署总览](#三部署总览)
4. [第 1 步：配置 SSH 免密登录](#四第-1-步配置-ssh-免密登录)
5. [第 2 步：传文件到路由器并部署](#五第-2-步传文件到路由器并部署)
6. [第 3 步：导出你自己的签到令牌](#六第-3-步导出你自己的签到令牌)
7. [第 4 步：配置微信推送](#七第-4-步配置微信推送)
8. [怎么改签到时间](#八怎么改签到时间)
9. [日常怎么查看状态](#九日常怎么查看状态)
10. [出问题了怎么办](#十出问题了怎么办)
11. [安全须知（必读）](#十一安全须知必读)
12. [文件清单](#十二文件清单)

---

## 一、这个工具是干什么的

WorkBuddy 每天签到能领积分，但人总有忘记的时候。这个工具做的事：

- 在你家的 **OpenWrt 软路由**上装一套 Python 小脚本，路由器的 cron **每天自动执行**；
- 默认给两个账号分别设 **07:30** 和 **07:40**（各自令牌、互不干扰）；
- 签到失败会**自动重试 4 次**，间隔递增 2 / 5 / 10 / 20 秒；重试期间不打扰你，
  4 次全失败才在汇总里提示手动补签；
- 两个账号都跑完后，由汇总脚本**只发一条**方糖（Server酱）微信推送，
  每个账号独立占一行，成功 / 已签 / 失败一目了然；
- 电脑只在部署和导出令牌时用一下，平时开不开机完全无所谓，路由器 7×24 在线。

它**不需要**你的账号密码，用的是你自己从客户端导出的一枚"长效通行证"（令牌），
令牌只放在你自己的路由器上，权限 600，只有 root 能读。

---

## 二、你需要准备什么

| 序号 | 需要的东西 | 说明 |
|---|---|---|
| 1 | 一台 OpenWrt 软路由 | 能登录管理页（LuCI），你知道 root 密码。x86 / arm 都行 |
| 2 | 一台 Windows 电脑 | 装了 WorkBuddy 客户端，并且**已经登录**你的账号（只用于导出令牌） |
| 3 | 电脑上有 Python 3.6 以上 | 导出令牌那一步要用（第 3 步会教你怎么装） |
| 4 | 一个方糖（Server酱）账号 | 免费注册，用来收微信汇总推送（第 4 步会教） |

> **不确定路由器是不是 OpenWrt？** 浏览器打开路由器管理页（一般是
> `http://192.168.1.1`），如果页面左上角写着 OpenWrt / LuCI，就是了。

---

## 三、部署总览

整个过程一共 4 步，大约 20 分钟：

```
第 1 步  配 SSH 免密登录（以后电脑连路由器不用输密码）   ~10 分钟
第 2 步  把文件传上去，跑部署脚本                        ~3 分钟
第 3 步  导出你自己的令牌传给路由器（核心步骤）           ~5 分钟
第 4 步  注册方糖，配置微信推送                          ~3 分钟
```

每一步都给了可以直接复制的命令。**复制命令时整行复制，一行一行来**，
不要一次粘好几行。

> **想省事？** 可以把本 README 整个文件发给 WorkBuddy，让它照着帮你操作。
> **不要把路由器密码发给它**，密码只在你自己的终端里输。

本包里**不含任何人的令牌、SendKey、账号显示名或路由器地址**，全部需要你自己填。

---

## 四、第 1 步：配置 SSH 免密登录

### 什么是 SSH？

SSH 就是"从你的电脑远程操作路由器的命令行"。OpenWrt 没有桌面，
所有操作都在命令行里完成。配好"免密登录"后，电脑连路由器就不用每次输密码。

### 1.0 先确认你的路由器固件类型（很关键）

这一步"该用哪种钥匙"**不看你电脑，只看路由器上的 OpenWrt 固件版本**。
OpenWrt 用的 SSH 服务端叫 `Dropbear`，它对"客户端钥匙"的接受规则随固件
年代不同而不一样——

| 路由器固件情况 | 只认哪种钥匙 | 怎么判断 |
|---|---|---|
| **新固件**：OpenWrt 24.x / 2024 以后常见编译版（内核 6.x） | **ed25519** | LuCI 底部版本号含 24.x；或 `uname -a` 内核显示 6.x |
| **老固件**：OpenWrt 21.x / 2023 及更早常见编译版（内核 5.x 及以下） | **RSA 2048** | 版本号 21.x 或更低；或 `uname -a` 内核 5.x 及以下 |

> **为什么会这样？** 老 Dropbear 只接受 RSA 签名，ed25519 公钥会被无视；
> 新 Dropbear 反过来拒绝 RSA 客户端钥匙，只认 ed25519。钥匙类型选错，
> 就会一直 `Permission denied`（正是本工具早期踩过的坑，所以才要你先确认）。

**最省心的做法（推荐新手）：** 直接按下面 1.1 生成 **ed25519** 钥匙；
到 1.3 测试时如果**还是要密码 / 报 `Permission denied`**，说明你是老固件，
回头把 1.1 的命令换成 `ssh-keygen -t rsa -b 2048 -f "...openwrt_rsa" -N '""'`、
1.2 改用 `openwrt_rsa.pub` 即可。

### 1.1 生成一把"钥匙"

按键盘上的 `Win` 键，直接输入 `powershell`，回车，打开一个蓝底窗口。
在窗口里粘贴这行（鼠标右键粘贴），回车：

```powershell
ssh-keygen -t ed25519 -f "$env:USERPROFILE\.ssh\openwrt_ed25519" -N '""'
```

- 中途问你要不要覆盖（`Overwrite (y/n)?`）就输 `y` 回车
- 最后会显示一把钥匙的"指纹图案"，说明生成成功

> 第一次用 ssh 的话，这行命令会自动创建 `.ssh` 文件夹，不用手动建。

### 1.2 把"钥匙"装进路由器

仍然在 PowerShell 里，执行（**把 `192.168.1.1` 换成你路由器的实际 IP**）：

```powershell
type $env:USERPROFILE\.ssh\openwrt_ed25519.pub | ssh root@192.168.1.1 "mkdir -p /etc/dropbear && cat >> /etc/dropbear/authorized_keys && chmod 700 /etc/dropbear && chmod 600 /etc/dropbear/authorized_keys"
```

- 第一次连接会问 `Are you sure you want to continue connecting (yes/no)?`
  输 `yes` 回车
- 然后提示输密码：**输密码时屏幕上什么都不显示，连星号都没有，
  这是正常的**，盲打完整密码回车即可

### 1.3 测试免密是否生效

```powershell
ssh root@192.168.1.1 "echo 免密成功"
```

- 如果直接输出 `免密成功`（没要密码）→ ✅ 第 1 步完成
- 如果还是要密码 → 上面 1.2 的命令没执行成功，重做一遍；
  还不行见[排障手册](#十出问题了怎么办)

---

## 五、第 2 步：传文件到路由器并部署

### 2.1 解压本包

把收到的 zip 解压到一个**路径简单**的地方，推荐 `D:\wb-checkin`。
解压后里面有个 `workbuddy-checkin` 文件夹，里面是各种脚本和这份教程。

### 2.2 上传文件

在 PowerShell 里（假设你解压到了 `D:\wb-checkin`）：

```powershell
cd D:\wb-checkin\workbuddy-checkin
ssh root@192.168.1.1 "mkdir -p /tmp/wb-deploy"
scp .\* root@192.168.1.1:/tmp/wb-deploy/
```

最后一条命令会刷出一串 `100%`，全部走完就是传完了。

### 2.3 运行部署脚本

```powershell
ssh root@192.168.1.1 "sh /tmp/wb-deploy/deploy_to_openwrt.sh"
```

脚本会自动做这些事，**全程你只需要看输出**：

1. 检查路由器上有没有 Python、ssl 模块（缺啥尝试装啥）
2. 把脚本安装到 `/root/.workbuddy/scripts/`
3. 做一次**只读连通性检查**（只查状态，不会真的签到、不会消耗推送条数）
4. 写入两条定时任务：**账号1 07:30**、**账号2 07:40**；
   两条都带 `--no-notify`（各自不单独推送），账号2 跑完后自动执行 `push_summary.py`
   发出当天唯一一条汇总推送
5. 启用并重启 cron 服务

看到最后打印"完成"和路径一览就是部署成功了。
**此时先别急，令牌还没导，签到还跑不起来**——继续第 3 步。

> 只想重刷定时任务、不动脚本时，用 `sh /tmp/wb-deploy/setcron.sh` 即可。
> 部署中途如果卡在 `opkg update` 或报网络错误，多半是路由器软件源连不上，
> 把最后 20 行输出发给分享给你这个工具的人求助。

### 2.4 关于"两个账号"（重要）

两个账号靠**各自的 HOME 目录**隔离，各自读自己的令牌：

| | 定时任务里的 HOME | 令牌存放位置 |
|---|---|---|
| 账号 1 | `/root` | `/root/.workbuddy/checkin-rt.json` |
| 账号 2 | `/root/.workbuddy2` | `/root/.workbuddy2/checkin-rt.json` |

第二个账号需要先建目录（部署脚本不会替你建）：

```powershell
ssh root@192.168.1.1 "mkdir -p /root/.workbuddy2 && chmod 700 /root/.workbuddy2"
```

**只需要一个账号？** 删掉 crontab 里 `40 7` 那一行，把 `push_summary.py`
挂到 `30 7` 那行末尾（用 `;` 连接），再把 `push_summary.py` 里的
`REPORTS` 列表只保留 `a1` 一项即可。

---

## 六、第 3 步：导出你自己的签到令牌

> **为什么每个人都要自己导？** 令牌等于你账号的"通行证"，跟账号走、
> 不跟电脑走。你的令牌只能证明你的身份，别人拿不到也用不了你的。

### 3.1 电脑上装 Python（已经装过的跳过）

打开 https://www.python.org/downloads/ 点黄色大按钮下载，
安装时**务必勾选底部的 `Add Python to PATH`**，再点 Install Now。
装完把 PowerShell 关掉重开一次。

### 3.2 装一个解密小工具

PowerShell 里执行：

```powershell
pip install pycryptodome
```

### 3.3 导出令牌

确认电脑上的 WorkBuddy 客户端**已经登录**，然后在**解压出来的
`workbuddy-checkin` 文件夹里**打开 PowerShell（在该文件夹的地址栏输入
`powershell` 回车，就会在这个目录打开），执行：

```powershell
python rt_auth.py --export-rt --save
```

成功的话会提示令牌已保存到 `C:\Users\你的用户名\.workbuddy\checkin-rt.json`。

### 3.4 传到路由器并验证

账号 1：

```powershell
scp $env:USERPROFILE\.workbuddy\checkin-rt.json root@192.168.1.1:/root/.workbuddy/
ssh root@192.168.1.1 "chmod 600 /root/.workbuddy/checkin-rt.json && cd /root/.workbuddy/scripts && HOME=/root python3 rt_auth.py --check --no-notify"
```

账号 2（先按 2.4 建好目录，再在**已登录第二个账号的电脑**上重复 3.3，
把导出的文件传过去）：

```powershell
scp $env:USERPROFILE\.workbuddy\checkin-rt.json root@192.168.1.1:/root/.workbuddy2/
ssh root@192.168.1.1 "chmod 600 /root/.workbuddy2/checkin-rt.json && cd /root/.workbuddy/scripts && HOME=/root/.workbuddy2 python3 rt_auth.py --check --no-notify"
```

看到输出里有 `"status": "ok"` 和积分余额 → ✅ 全部打通！
从明天早上 7:30 开始自动签到，7:40 第二个账号跑完后收到一条汇总推送。

---

## 七、第 4 步：配置微信推送

不配置也能签到，但**失败了没人告诉你**，所以强烈建议配。

### 4.1 注册方糖拿 SendKey

1. 浏览器打开 **👉 [点这里注册方糖 Server酱](https://sct.ftqq.com/r/28382)**
   （通过这个邀请链接注册，是对打包分享者的**支持**；你付的费用
   一分不多，免费版照样每天 5 条推送）
2. 微信扫码登录
3. 点「SendData」→「Key」页，复制那串以 `SCT` 开头的 SendKey
4. 按提示用微信关注「方糖」服务号并绑定（不绑收不到消息）

### 4.2 填进路由器

包里的 `notify_config.json` 长这样（**只是模板，SendKey 是占位符**）：

```json
{
  "enabled": true,
  "success_notify": true,
  "channels": {
    "webhook": {
      "url": "https://sctapi.ftqq.com/把这里替换成你自己的SendKey.send",
      "form": true,
      "payload_template": "title={{title}}&desp={{content}}"
    }
  }
}
```

```powershell
ssh root@192.168.1.1 "vi /root/.workbuddy/scripts/notify_config.json"
```

vi 操作小白版：按键盘 `i` 进入编辑 → 找到 `把这里替换成你自己的SendKey`
那一段，删掉换成你的 SCT 开头的 Key → 按 `Esc` → 输入 `:wq` 回车保存退出。

> **别删 `form` 和 `payload_template` 两行**：方糖的正文要放在 `desp` 字段里，
> 而且 `desp` 是 Markdown；少了这两行，正文会变成 `content` 字段，
> 推送要么没内容、要么两个账号挤成一行。

> 怕 vi 手抖的话，也可以先在电脑上用记事本改好包里的
> `notify_config.json`（第 2.2 步上传之前改），再重新 scp 一遍。

### 4.3 测试推送

```powershell
ssh root@192.168.1.1 "cd /root/.workbuddy/scripts && python3 push_message.py --test 部署成功"
```

你微信收到消息 → ✅ 大功告成。

想顺手看看汇总排版，可以再跑一次（会消耗 1 条推送额度）：

```powershell
ssh root@192.168.1.1 "cd /root/.workbuddy/scripts && python3 push_summary.py"
```

两个账号各占一行；如果报告文件还没生成，会显示"无结果文件"，属正常，
等到第二天定时任务跑完就是真实结果了。

> 方糖免费版每天 5 条推送，**汇总方案每天只用 1 条**，非常宽裕。

### 4.4 可选：给账号起个显示名

默认推送里显示中性的「账号 1 / 账号 2」。想显示自己认得的叫法，
在路由器上建一个**本地私有**文件：

```powershell
ssh root@192.168.1.1 "vi /root/.workbuddy/scripts/push_names.json"
```

内容示例（名字随你写，只保存在你自己的路由器上）：

```json
{"a1": "我的账号", "a2": "另一个账号"}
```

```powershell
ssh root@192.168.1.1 "chmod 600 /root/.workbuddy/scripts/push_names.json"
```

这个文件**不在分享包里、也不需要上传给任何人**；脚本读不到时会自动回退
「账号 1 / 账号 2」，不影响签到和推送。

---

## 八、怎么改签到时间

默认两个账号分别在 07:30 与 07:40。以第一个账号为例，假设想改成 8:30：

```powershell
ssh root@192.168.1.1 "crontab -l > /tmp/c && sed -i 's/30 7 \* \* \*/30 8 * * */' /tmp/c && crontab /tmp/c && crontab -l"
```

规律就是 `分 时 日 月 周`，`30 7` 就是 7 点 30 分；改第二个账号同理把 `40 7` 换成你要的时间。

> **注意顺序**：汇总推送挂在账号 2 那行末尾，所以账号 2 的时间要晚于账号 1，
> 否则汇总发出去时账号 1 的结果可能还没写好。
>
> 另外 OpenWrt 默认时区可能是 UTC（比北京时间慢 8 小时）。
> 部署脚本运行时会打印当前时区；如果显示 UTC，7:30 实际是北京时间下午 15:30。
> 在 LuCI「系统 → 系统设置」把时区改成 `Asia/Shanghai` 即可。

---

## 九、日常怎么查看状态

**方式一（最省事）：** 收微信推送。每天两个账号跑完后收到一条汇总，
每个账号单独一行；只有重试 4 次仍失败才会提示手动补签。

**方式二：** 浏览器登录路由器管理页 → 「系统」→「计划任务」，
能看到那两行就说明任务还在。

**方式三（命令行）：**

```powershell
ssh root@192.168.1.1 "tail -n 20 /root/.workbuddy/scripts/checkin.log"
ssh root@192.168.1.1 "tail -n 20 /root/.workbuddy/scripts/checkin-acct2.log"
ssh root@192.168.1.1 "crontab -l"
```

---

## 十、出问题了怎么办

| 现象 | 原因与处理 |
|---|---|
| 免密登录配不上，一直要密码 | ① 确认用的是 **ed25519** 公钥（本教程生成的就是 `openwrt_ed25519.pub`）；② 路由器把公钥写错了位置，手动执行：`type $env:USERPROFILE\.ssh\openwrt_ed25519.pub \| ssh root@IP "cat >> /etc/dropbear/authorized_keys && chmod 600 /etc/dropbear/authorized_keys"` |
| ssh 连路由器报 `Bad permissions` | Windows 的 OpenSSH 要求私钥文件权限不能太开放：管理员 PowerShell 执行 `icacls "$env:USERPROFILE\.ssh\openwrt_ed25519" /inheritance:r /grant:r "$env:USERNAME:F"`，再重试 |
| 部署脚本报 `python3-ssl` 相关 | SSH 进路由器执行 `opkg update && opkg install python3-ssl`，然后重跑部署脚本 |
| 推送收不到但签到正常 | 方糖的「方糖」服务号没关注/被折叠了；SendKey 填错也会这样 |
| 推送只有标题、没有正文 / 两个账号挤在一行 | `notify_config.json` 里的 `form` 或 `payload_template` 被删了，按 4.2 的模板补回来（正文必须走 `desp`） |
| 账号 2 显示"无结果文件" | `/root/.workbuddy2` 没建，或第二个账号的令牌没传上去；按 2.4 / 3.4 补做 |
| 汇总里出现"签到失败，请手动补签" | 已自动重试 4 次仍失败；先看日志，多半是令牌失效：客户端重新登录一次，重做第 3 步 |
| 客户端突然要求重新登录 | 正常现象（见上条），登录即可，不影响路由器 |
| 想彻底停用 | `ssh root@IP "crontab -l \| grep -v auto_checkin \| grep -v push_summary \| crontab -"` 删掉定时任务；`rm -rf /root/.workbuddy /root/.workbuddy2` 删掉全部文件 |

---

## 十一、安全须知（必读）

1. **`checkin-rt.json` 等于你的账号钥匙**——永远不要发给任何人、
   不要截图、不要上传网盘。
2. **填了自己 SendKey 的 `notify_config.json`** 不要外发，
   别人拿到能冒充你推消息。
3. `push_names.json` 是你自己的私有配置，同样不需要外发。
4. 电脑上用于导出令牌的那份 `~/.workbuddy/checkin-rt.json`，导完传上去后可以删。
5. 本分享包里的脚本**不包含任何人的令牌、密钥、显示名或路由器地址**，
   可以放心转发。

---

## 十二、文件清单

| 文件 | 作用 |
|---|---|
| `README.md` | 本教程 |
| `auto_checkin.py` | 签到总指挥（cron 每天调它） |
| `rt_auth.py` | 长效令牌：导出 / 刷新 / 查询 / 写当日报告 |
| `workbuddy_checkin.py` | 签到核心逻辑（已签判定、失败重试、领取与旅行） |
| `web_auth.py` | 网页授权通道（备用） |
| `push_message.py` | 推送模块（方糖 / 钉钉 / 飞书 / bark 等） |
| `push_summary.py` | 多账号结果合并推送（每个账号独立一行） |
| `deploy_to_openwrt.sh` | 一键部署脚本（装脚本 + 写 crontab） |
| `setcron.sh` | 只重刷两条定时任务 |
| `notify_config.json` | 推送配置模板（SendKey 为占位符，需自行替换） |

> 需要自建、不在包里的文件：`checkin-rt.json`（令牌）、`push_names.json`（可选显示名）。

---

*祝挂机愉快。部署卡住了就带着报错截图来问。*
