#!/bin/sh
# 设置双账号签到 crontab（账号1 07:30 / 账号2 07:40 + 汇总推送）
# 用法：在 OpenWrt 上 sh setcron.sh
SCRIPTS_DIR="/root/.workbuddy/scripts"

crontab -l 2>/dev/null | grep -v "auto_checkin.py" | grep -v "push_summary.py" > /tmp/cron.tmp

cat >> /tmp/cron.tmp <<'CRON'
30 7 * * * cd /root/.workbuddy/scripts && HOME=/root /usr/bin/python3 /root/.workbuddy/scripts/auto_checkin.py --rt --no-notify --report-file /root/.workbuddy/checkin_report_a1.json >> /root/.workbuddy/scripts/checkin.log 2>&1
40 7 * * * cd /root/.workbuddy/scripts && HOME=/root/.workbuddy2 /usr/bin/python3 /root/.workbuddy/scripts/auto_checkin.py --rt --no-notify --report-file /root/.workbuddy/checkin_report_a2.json >> /root/.workbuddy/scripts/checkin-acct2.log 2>&1 ; /usr/bin/python3 /root/.workbuddy/scripts/push_summary.py >> /root/.workbuddy/scripts/checkin-acct2.log 2>&1
CRON

crontab /tmp/cron.tmp
rm -f /tmp/cron.tmp

/etc/init.d/cron enable 2>/dev/null
/etc/init.d/cron restart 2>/dev/null || /etc/init.d/cron start 2>/dev/null

echo "crontab updated:"
crontab -l | grep -E "auto_checkin.py|push_summary.py"
