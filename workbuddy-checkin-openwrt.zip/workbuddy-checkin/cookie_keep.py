#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""网页会话凭据守护（cookie keeper）

用途
    通道 B（网页 Cookie）的凭据会过期。本脚本负责：
      1. 每次运行都真调一次「只读状态接口」，用结果判断凭据是否还活着（唯一权威判据）
      2. 顺便吸收服务端下发的 Set-Cookie —— 若后端在滑动续期，这里会自动把新 Cookie 存回去
      3. 解析并记录到期时间（能解析到就精确算，解析不到就按失败次数兜底）
      4. 临期（默认 5 天）或已失效时，主动推一条通知，附带重新导出的步骤

用法
    python3 cookie_keep.py --status           # 只看，不改文件（仍会发一次只读请求）
    python3 cookie_keep.py --keep             # cron 用：校验 + 自动吸收 Set-Cookie + 预警
    python3 cookie_keep.py --keep --no-notify # 静默，只写日志
选项
    --warn-days N   剩余天数低于 N 时预警，默认 5；给 0 关闭
    --json          以 JSON 输出
退出码
    0 正常 / 2 临期 / 3 未配置或已失效 / 4 网络异常

安全
    任何输出、日志都不含 Cookie 明文，只打印 cookie 名、长度与哈希前缀。
"""

import base64
import hashlib
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import web_auth as wa  # noqa: E402

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cookie_keep.log")
DEFAULT_WARN_DAYS = 5

# 这些名字的 Cookie 值本身是 JWT，可以解出 exp
JWT_COOKIE_HINTS = ("keycloak_identity", "keycloak_session", "access_token")


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------
def _now():
    return int(time.time())


def _fmt(ts):
    if not ts:
        return "-"
    try:
        return time.strftime("%Y-%m-%d %H:%M", time.localtime(int(ts)))
    except Exception:
        return "-"


def _sha(s):
    return hashlib.sha256(str(s).encode("utf-8", "replace")).hexdigest()[:12]


def _log(line):
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write("%s  %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), line))
    except Exception:
        pass


def _split_cookie(s):
    """'a=1; b=2' -> [['a','1'], ['b','2']]，保持顺序。"""
    out = []
    for seg in (s or "").split(";"):
        if "=" not in seg:
            continue
        k, v = seg.split("=", 1)
        k, v = k.strip(), v.strip()
        if k:
            out.append([k, v])
    return out


def _join_cookie(pairs):
    return "; ".join("%s=%s" % (k, v) for k, v in pairs if v)


def _jwt_exp(val):
    """三段式 JWT 取 payload.exp；取不到返回 None。"""
    parts = str(val).split(".")
    if len(parts) != 3:
        return None
    try:
        seg = parts[1]
        seg += "=" * (-len(seg) % 4)
        obj = json.loads(base64.urlsafe_b64decode(seg).decode("utf-8", "replace"))
        exp = obj.get("exp")
        return int(exp) if exp else None
    except Exception:
        return None


def _exp_from_setcookie(sc):
    """从 Set-Cookie 的 Max-Age / Expires 推到期时间戳。"""
    low = sc.lower()
    for part in low.split(";"):
        part = part.strip()
        if part.startswith("max-age="):
            try:
                sec = int(part.split("=", 1)[1].strip())
                if sec > 0:
                    return _now() + sec
            except Exception:
                pass
    if "expires=" in low:
        try:
            from email.utils import parsedate_to_datetime
            raw = sc[low.index("expires=") + 8:].split(";")[0].strip()
            return int(parsedate_to_datetime(raw).timestamp())
        except Exception:
            pass
    return None


def _cookie_headers(setcookies, pairs):
    """把 Set-Cookie 合并进现有 Cookie 串。返回 (新串, 是否变化, 事件列表)。"""
    idx = {k.lower(): i for i, (k, v) in enumerate(pairs)}
    changed = False
    events = []
    for sc in setcookies or []:
        first = sc.split(";", 1)[0]
        if "=" not in first:
            continue
        name, val = first.split("=", 1)
        name, val = name.strip(), val.strip()
        low = sc.lower().replace(" ", "")
        deleted = (val == "" or "max-age=0" in low)
        key = name.lower()
        if key in idx:
            i = idx[key]
            if deleted:
                if pairs[i][1] != "":
                    pairs[i][1] = ""
                    changed = True
                    events.append("删除 %s" % name)
            elif pairs[i][1] != val:
                pairs[i][1] = val
                changed = True
                events.append("更新 %s (len %d -> %d)" % (name, len(pairs[i][1]), len(val)))
        elif not deleted:
            idx[key] = len(pairs)
            pairs.append([name, val])
            changed = True
            events.append("新增 %s (len %d)" % (name, len(val)))
    return _join_cookie(pairs), changed, events


# ---------------------------------------------------------------------------
# 探测：捕获响应头
# ---------------------------------------------------------------------------
def probe(cred, base):
    """POST 状态接口，返回 (http, body, setcookies)。"""
    url = (base or "").rstrip("/") + wa.STATUS_PATH
    req = wa.urllib.request.Request(
        url, data=b"{}", headers=wa._headers(cred, base), method="POST")
    try:
        with wa.urllib.request.urlopen(req, timeout=wa.HTTP_TIMEOUT) as r:
            return r.status, wa._safe_json(r.read().decode("utf-8", "replace")), \
                (r.headers.get_all("Set-Cookie") or [])
    except wa.urllib.error.HTTPError as e:
        try:
            raw = e.read().decode("utf-8", "replace")
        except Exception:
            raw = ""
        return e.code, wa._safe_json(raw), (e.headers.get_all("Set-Cookie") or [])
    except Exception as e:
        return 0, {"_error": "%s: %s" % (type(e).__name__, str(e)[:120])}, []


def load_cred():
    obj = wa.read_cred()
    if not obj:
        return None
    try:
        with open(wa.CRED_FILE, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if isinstance(raw, dict):
            raw.update({k: v for k, v in obj.items() if v})
            return raw
    except Exception:
        pass
    return obj


def save_cred(obj):
    tmp = wa.CRED_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, wa.CRED_FILE)
    try:
        os.chmod(wa.CRED_FILE, 0o600)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 通知
# ---------------------------------------------------------------------------
def notify(title, content, enabled=True):
    if not enabled:
        return
    try:
        import push_message
        push_message.send_message(title, content)
    except Exception as e:
        _log("通知发送异常（已忽略）: %s" % type(e).__name__)


def _renew_guide():
    return (
        "重新授权（约 1 分钟，在你自己的电脑上做）：\n"
        "1) 浏览器登录 https://www.workbuddy.cn\n"
        "2) F12 -> Network -> F5 刷新 -> 右键任一请求 -> Copy as cURL (bash)\n"
        "3) ssh root@路由器IP\n"
        "4) python3 /root/.workbuddy/scripts/web_auth.py --setup-curl -\n"
        "   粘贴后按 Ctrl+D\n"
    )


# ---------------------------------------------------------------------------
# 主逻辑
# ---------------------------------------------------------------------------
def run(warn_days=DEFAULT_WARN_DAYS, do_notify=True, dry=False):
    res = {"state": "unknown", "mode": None, "expires_at": None,
           "expires_src": None, "days_left": None, "http": None,
           "cookie_changed": False, "events": [], "msg": ""}

    cred = load_cred()
    if not cred or not cred.get("value"):
        res.update(state="no_cred", msg="尚未配置网页凭据，请先执行 web_auth.py --setup-curl -")
        _log("no_cred")
        notify("WorkBuddy 签到：未配置网页凭据", res["msg"] + "\n\n" + _renew_guide(), do_notify)
        return res, 3

    res["mode"] = cred.get("mode") or ("cookie" if "=" in cred["value"] else "bearer")
    pairs = _split_cookie(cred["value"])
    res["cookie_names"] = [k for k, _ in pairs]

    # ---- 真请求一次（只读），这是唯一权威判据 ----
    st, body, setcookies = 0, {}, []
    used = ""
    for base in wa.probe_domains(cred):
        st, body, setcookies = probe(cred, base)
        used = base
        if st == 200 and (body or {}).get("code") == 0:
            break
        if st in (401, 403):
            break
    res["http"] = st
    res["domain"] = used

    ok = (st == 200 and (body or {}).get("code") == 0)
    data = (body or {}).get("data") or {}
    res["detail_data"] = {k: data.get(k) for k in
                          ("streak_days", "today_checked_in", "total_credits")}

    # ---- 吸收 Set-Cookie ----
    if res["mode"] == "cookie" and setcookies:
        newval, changed, events = _cookie_headers(setcookies, pairs)
        res["events"] = events
        if changed and newval:
            res["cookie_changed"] = True
            if not dry:
                cred["value"] = newval
                cred["cookie_len"] = len(newval)

    # ---- 到期时间 ----
    exp, src = None, None
    for sc in (setcookies or []):
        e = _exp_from_setcookie(sc)
        if e:
            exp, src = e, "Set-Cookie"
    if not exp and res["mode"] == "cookie":
        for k, v in pairs:
            if any(h in k.lower() for h in JWT_COOKIE_HINTS):
                e = _jwt_exp(v)
                if e:
                    exp, src = e, "JWT." + k
                    break
    if not exp and cred.get("expires_at"):
        exp, src = int(cred["expires_at"]), cred.get("expires_src") or "recorded"
    res["expires_at"], res["expires_src"] = exp, src
    if exp:
        res["days_left"] = round((exp - _now()) / 86400.0, 1)

    # ---- 判定 ----
    if ok:
        res["state"] = "ok"
        res["msg"] = "凭据有效。连续 %s 天，今日已签: %s，余额: %s" % (
            data.get("streak_days", "?"),
            "是" if data.get("today_checked_in") else "否",
            data.get("total_credits") or "?")
    elif st in (401, 403):
        res["state"] = "expired"
        res["msg"] = "凭据已失效（HTTP %d），签到无法继续" % st
    elif st == 0:
        res["state"] = "network"
        res["msg"] = "网络异常，无法判定凭据状态: %s" % str((body or {}).get("_error", ""))[:100]
    else:
        res["state"] = "suspect"
        res["msg"] = "接口返回异常（HTTP %s, code=%s），凭据可能仍有效" % (
            st, (body or {}).get("code"))

    # ---- 落盘状态 ----
    if not dry:
        cred["last_check_at"] = _now()
        cred["last_state"] = res["state"]
        cred["last_http"] = st
        if ok:
            cred["last_ok_at"] = _now()
            cred["fail_count"] = 0
        elif res["state"] in ("expired", "network", "suspect"):
            cred["fail_count"] = int(cred.get("fail_count") or 0) + 1
        if exp:
            cred["expires_at"] = exp
            cred["expires_src"] = src
        save_cred(cred)

    # ---- 通知策略 ----
    if res["state"] == "expired":
        _log("expired http=%s" % st)
        notify("WorkBuddy 签到：网页凭据已失效",
               "路由器上的网页授权凭据已失效，今天的签到会失败。\n\n" + _renew_guide(),
               do_notify)
        return res, 3

    if res["state"] == "network":
        fc = int(cred.get("fail_count") or 0)
        _log("network fail_count=%d %s" % (fc, res["msg"][:80]))
        if fc >= 3:
            notify("WorkBuddy 签到：连续 %d 次连不上接口" % fc,
                   "凭据未必失效，但连续 %d 次请求失败，请检查路由器网络。\n最后错误: %s"
                   % (fc, res["msg"][:160]), do_notify)
        return res, 4

    if res["state"] == "ok" and exp and warn_days > 0:
        dl = (exp - _now()) / 86400.0
        if dl <= warn_days:
            stamp = time.strftime("%Y-%m-%d", time.localtime(exp))
            _log("expiring days_left=%.1f exp=%s" % (dl, stamp))
            notify("WorkBuddy 签到：网页凭据 %s 到期" % stamp,
                   "还剩 %.0f 天。到期后签到会失败，建议现在重新导一次。\n\n%s"
                   % (max(dl, 0), _renew_guide()), do_notify)
            return res, 2

    _log("ok state=%s changed=%s events=%s" % (
        res["state"], res["cookie_changed"], ";".join(res["events"])[:120]))
    return res, 0


def main(argv):
    status_only = "--status" in argv
    keep = "--keep" in argv or status_only
    do_notify = "--no-notify" not in argv
    warn_days = DEFAULT_WARN_DAYS
    if "--warn-days" in argv:
        try:
            warn_days = int(argv[argv.index("--warn-days") + 1])
        except Exception:
            pass

    if "--help" in argv or "-h" in argv or not keep:
        print(__doc__)
        return 0

    res, code = run(warn_days=warn_days, do_notify=do_notify, dry=status_only)

    if "--json" in argv:
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return code

    print("凭据模式   %s" % res.get("mode"))
    print("Cookie 项  %s" % (", ".join(res.get("cookie_names") or []) or "-"))
    print("校验域名   %s" % (res.get("domain") or "-"))
    print("接口返回   HTTP %s" % res.get("http"))
    print("状态       %s" % res.get("state"))
    print("到期时间   %s%s" % (
        _fmt(res.get("expires_at")),
        "  (剩余 %.1f 天)" % res["days_left"] if res.get("days_left") is not None else ""))
    if res.get("events"):
        print("Cookie 变化 %s" % "；".join(res["events"]))
    print("说明       %s" % res.get("msg"))
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
