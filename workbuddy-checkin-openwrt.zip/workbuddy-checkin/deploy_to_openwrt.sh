#!/bin/sh
# WorkBuddy 签到助手 — OpenWrt 部署脚本
# 用法：在 OpenWrt 上以 root 执行（或由 WorkBuddy 通过 ssh 远程执行）
#   sh deploy_to_openwrt.sh
#
# 前置：本脚本与以下文件位于同一目录
#   auto_checkin.py push_message.py rt_auth.py web_auth.py workbuddy_checkin.py
#   push_summary.py notify_config.json
#   令牌 checkin-rt.json 可选：若同目录存在则一并安装到账号1，否则稍后自行上传
#
# 作用：装到 /root/.workbuddy/scripts → 检查 python3 →
#       写入 crontab（账号1 07:30 / 账号2 07:40 + 账号2 跑完后汇总推送一次）

set -e

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
HOME_DIR="/root"
WB_DIR="$HOME_DIR/.workbuddy"
SCRIPTS_DIR="$WB_DIR/scripts"

echo "=== [1/6] 环境检查 ==="
PY=""
for c in python3 /usr/bin/python3 /usr/local/bin/python3; do
  if command -v "$c" >/dev/null 2>&1; then PY="$(command -v "$c")"; break; fi
done
if [ -z "$PY" ]; then
  echo "未找到 python3，尝试 opkg 安装..."
  if command -v opkg >/dev/null 2>&1; then
    opkg update >/dev/null 2>&1 || true
    opkg install python3-light python3-urllib python3-json python3-ssl 2>/dev/null \
      || opkg install python3 2>/dev/null || true
    for c in python3 /usr/bin/python3; do
      if command -v "$c" >/dev/null 2>&1; then PY="$(command -v "$c")"; break; fi
    done
  fi
fi
if [ -z "$PY" ]; then
  echo "ERROR: 无法获得 python3。请手动 opkg install python3 后重跑本脚本。"
  exit 1
fi
echo "python3: $PY"
"$PY" -V
echo "架构: $(uname -m)"

echo "=== [2/6] 创建目录 ==="
mkdir -p "$SCRIPTS_DIR"
chmod 700 "$WB_DIR" 2>/dev/null || true

echo "=== [3/6] 拷贝脚本与配置 ==="
for f in auto_checkin.py push_message.py rt_auth.py web_auth.py workbuddy_checkin.py push_summary.py; do
  [ -f "$SRC_DIR/$f" ] || { echo "ERROR: 缺少 $f"; exit 1; }
  cp -f "$SRC_DIR/$f" "$SCRIPTS_DIR/$f"
  chmod 755 "$SCRIPTS_DIR/$f"
done
[ -f "$SRC_DIR/notify_config.json" ] && cp -f "$SRC_DIR/notify_config.json" "$SCRIPTS_DIR/notify_config.json"
[ -f "$SRC_DIR/checkin-rt.json" ] && { cp -f "$SRC_DIR/checkin-rt.json" "$WB_DIR/checkin-rt.json"; chmod 600 "$WB_DIR/checkin-rt.json"; }
chmod 600 "$SCRIPTS_DIR/notify_config.json" 2>/dev/null || true
echo "已安装到 $SCRIPTS_DIR"

echo "=== [4/6] 连通性检查（只读，不领取、不推送） ==="
cd "$SCRIPTS_DIR"
"$PY" rt_auth.py --check --no-notify 2>&1 | tail -20 || {
  echo "WARN: 连通性检查返回非零，请查看上面输出（可能是网络或令牌问题）"
}

echo "=== [5/6] 配置 crontab（账号1 07:30 / 账号2 07:40） ==="
# 两个账号各自静默运行（--no-notify 不单独推送），分别写出报告文件；
# 账号2 跑完后再由 push_summary.py 合并发一条方糖（微信）汇总
CRON_A1="30 7 * * * cd $SCRIPTS_DIR && HOME=/root $PY $SCRIPTS_DIR/auto_checkin.py --rt --no-notify --report-file /root/.workbuddy/checkin_report_a1.json >> $SCRIPTS_DIR/checkin.log 2>&1"
CRON_A2="40 7 * * * cd $SCRIPTS_DIR && HOME=/root/.workbuddy2 $PY $SCRIPTS_DIR/auto_checkin.py --rt --no-notify --report-file /root/.workbuddy/checkin_report_a2.json >> $SCRIPTS_DIR/checkin-acct2.log 2>&1 ; $PY $SCRIPTS_DIR/push_summary.py >> $SCRIPTS_DIR/checkin-acct2.log 2>&1"
if command -v crontab >/dev/null 2>&1; then
  TMP="$(mktemp)"
  crontab -l 2>/dev/null | grep -v "auto_checkin.py" | grep -v "push_summary.py" > "$TMP" || true
  echo "$CRON_A1" >> "$TMP"
  echo "$CRON_A2" >> "$TMP"
  crontab "$TMP"
  rm -f "$TMP"
  echo "crontab 已写入："
  crontab -l | grep -E "auto_checkin.py|push_summary.py"
  # 确保 cron 服务在跑
  /etc/init.d/cron enable 2>/dev/null || true
  /etc/init.d/cron restart 2>/dev/null || /etc/init.d/cron start 2>/dev/null || true
else
  echo "ERROR: 无 crontab 命令。请在 LuCI 系统→计划任务 手动添加："
  echo "$CRON_A1"
  echo "$CRON_A2"
  exit 1
fi

echo "=== [6/6] 完成 ==="
echo "日志文件: $SCRIPTS_DIR/checkin.log"
echo "只读测试（不领取不推送）:      $PY $SCRIPTS_DIR/auto_checkin.py --rt --check-only --no-notify"
echo "手动跑一次汇总推送（会消耗 1 条推送额度）: $PY $SCRIPTS_DIR/push_summary.py"
echo ""
echo "提示：两个账号各自使用独立 HOME 读取自己的令牌——"
echo "  账号1: /root/.workbuddy/checkin-rt.json"
echo "  账号2: /root/.workbuddy2/checkin-rt.json   （需先 mkdir -p /root/.workbuddy2）"
echo "只想用一个账号时，删除 crontab 里 40 7 那行，并把 push_summary.py 挂到 30 7 那行末尾。"
