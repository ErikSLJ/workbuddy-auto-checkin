#!/bin/sh
# WorkBuddy 签到助手 · OpenWrt 部署脚本 v2
# 由 WorkBuddy 重新编写，替代原 deploy_to_openwrt.sh
# 相对原版的改进：
#   1. 强制校验 ssl 模块（原版没验，缺失会导致推送静默失效）
#   2. 强制校验 CA 证书（原版没验，缺失会导致 HTTPS 全部 CERTIFICATE_VERIFY_FAILED）
#   3. Python 版本守卫（< 3.6 直接拒绝）
#   4. 真实 HTTPS 连通性测试（三个域名逐个探）
#   5. crontab 里显式带 HOME=/root（原版没有，cron 环境下 expanduser 有隐患）
#   6. crontab 写入前留备份
#   7. 时区打印（cron 的 9 点是服务器本地时间，时区错就全错）

set -eu

SRC="$(cd "$(dirname "$0")" && pwd)"
WB="/root/.workbuddy"
SC="$WB/scripts"

say()  { echo "[deploy] $*"; }
warn() { echo "[WARN  ] $*"; }
die()  { echo "[FAIL  ] $*"; exit 1; }

say "=== 1/7 系统信息 ==="
ARCH="$(uname -m)"
if [ -f /etc/openwrt_release ]; then
  . /etc/openwrt_release
  say "OpenWrt ${DISTRIB_RELEASE:-unknown} / ${DISTRIB_ARCH:-unknown}"
fi
say "内核架构: $ARCH"
say "当前时间: $(date '+%Y-%m-%d %H:%M:%S %Z %z')"

say "=== 2/7 Python 环境 ==="
PY=""
for c in python3 /usr/bin/python3 /usr/local/bin/python3; do
  if command -v "$c" >/dev/null 2>&1; then PY="$(command -v "$c")"; break; fi
done

if [ -z "$PY" ]; then
  say "未检测到 python3，开始安装（可能需要几分钟）"
  command -v opkg >/dev/null 2>&1 || die "无 opkg，无法安装 python3"
  opkg update || warn "opkg update 失败，仍尝试安装"
  opkg install python3-light python3-urllib python3-json python3-ssl ca-bundle \
    || die "python3 安装失败：请检查软件源或网络"
  for c in python3 /usr/bin/python3; do
    if command -v "$c" >/dev/null 2>&1; then PY="$(command -v "$c")"; break; fi
  done
fi
[ -n "$PY" ] || die "python3 仍不可用"
say "python3: $PY"
"$PY" -V 2>&1

"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3,6) else 1)' \
  || die "Python 版本低于 3.6，脚本要求 3.6+"

say "--- 校验 ssl 模块（push_message.py 顶层 import，缺失则推送全挂）---"
"$PY" -c 'import ssl; print("  ssl OK:", ssl.OPENSSL_VERSION)' \
  || die "ssl 模块缺失，请执行: opkg install python3-ssl"

say "--- 校验 CA 证书 ---"
CAFOUND=0
for f in /etc/ssl/certs/ca-certificates.crt /etc/ssl/cert.pem /etc/ssl/certs; do
  if [ -e "$f" ]; then say "  找到: $f"; CAFOUND=1; break; fi
done
if [ "$CAFOUND" = "0" ]; then
  warn "未找到系统 CA 证书，HTTPS 可能验证失败"
  opkg install ca-bundle >/dev/null 2>&1 || warn "ca-bundle 安装失败"
fi

say "--- HTTPS 连通性实测 ---"
"$PY" - <<'PYEOF'
import urllib.request, sys
urls = ("https://www.codebuddy.cn", "https://www.workbuddy.cn",
        "https://copilot.tencent.com")
bad = 0
for u in urls:
    try:
        with urllib.request.urlopen(u, timeout=12) as r:
            print("  OK   %-34s HTTP %s" % (u, r.status))
    except urllib.error.HTTPError as e:
        print("  OK   %-34s HTTP %s (服务端拒绝，但 TLS 已通)" % (u, e.code))
    except Exception as e:
        bad += 1
        print("  ERR  %-34s %s: %s" % (u, type(e).__name__, str(e)[:90]))
sys.exit(1 if bad == len(urls) else 0)
PYEOF

say "=== 3/7 磁盘空间 ==="
df -h /overlay 2>/dev/null || df -h / 2>/dev/null || warn "无法读取磁盘信息"

say "=== 4/7 安装文件 ==="
mkdir -p "$SC"
chmod 700 "$WB" 2>/dev/null || true

for f in auto_checkin.py rt_auth.py workbuddy_checkin.py push_message.py web_auth.py cookie_keep.py; do
  [ -f "$SRC/$f" ] || die "缺少文件: $f"
  cp -f "$SRC/$f" "$SC/$f"
  chmod 755 "$SC/$f"
done

[ -f "$SRC/notify_config.json" ] || die "缺少 notify_config.json"
cp -f "$SRC/notify_config.json" "$SC/notify_config.json"
chmod 600 "$SC/notify_config.json"

if [ -f "$SRC/checkin-rt.json" ]; then
  cp -f "$SRC/checkin-rt.json" "$WB/checkin-rt.json"
  chmod 600 "$WB/checkin-rt.json"
else
  say "包内无 checkin-rt.json（正常，令牌需要每个人自己导出）"
  say "部署完成后请看 README 第 3 步导出你自己的令牌"
fi

say "已安装:"
ls -l "$SC" "$WB/checkin-rt.json"

say "=== 5/7 只读验证（查询状态，不领取、不推送）==="
cd "$SC"
if [ ! -f "$WB/checkin-rt.json" ] && [ ! -f "$WB/checkin-cred.json" ]; then
  say "尚未配置任何凭据，跳过验证（导出令牌后可重跑本脚本）"
elif [ -f "$WB/checkin-cred.json" ]; then
  say "已配置网页凭据，走通道 B 校验"
  "$PY" cookie_keep.py --status --no-notify || warn "凭据校验返回非零，请按提示重新授权"
  "$PY" auto_checkin.py --web --check-only --no-notify || warn "只读验证返回非零，请看上方输出"
else
  say "未配置网页凭据（通道 B），退回通道 C 校验"
  "$PY" rt_auth.py --check --no-notify || warn "只读验证返回非零，请看上方输出"
fi

say "=== 6/7 配置定时任务 ==="
START_HOUR="${WB_START_HOUR:-9}"
# 凭据守护提前 5 分钟跑，先校验再签到
TOTAL=$(( START_HOUR * 60 - 5 ))
[ "$TOTAL" -lt 0 ] && TOTAL=$(( 24 * 60 - 5 ))
KH=$(( TOTAL / 60 ))
KM=$(( TOTAL % 60 ))

KEEP_LINE="$KM $KH * * * cd $SC && HOME=/root $PY $SC/cookie_keep.py --keep >> $SC/cookie_keep.log 2>&1"
CRON_LINE="0 $START_HOUR * * * cd $SC && HOME=/root $PY $SC/auto_checkin.py --web >> $SC/checkin.log 2>&1"

if command -v crontab >/dev/null 2>&1; then
  TMP="$(mktemp)"
  crontab -l 2>/dev/null | grep -v "auto_checkin.py" | grep -v "cookie_keep.py" > "$TMP" || true
  cp "$TMP" "$WB/crontab.bak" 2>/dev/null || true
  echo "$KEEP_LINE" >> "$TMP"
  echo "$CRON_LINE" >> "$TMP"
  crontab "$TMP"
  rm -f "$TMP"
  say "定时任务已写入:"
  crontab -l | grep -E "auto_checkin|cookie_keep" || true
  /etc/init.d/cron enable  >/dev/null 2>&1 || true
  /etc/init.d/cron restart >/dev/null 2>&1 || /etc/init.d/cron start >/dev/null 2>&1 \
    || warn "cron 服务启动失败，请手动 /etc/init.d/cron start"
else
  warn "无 crontab 命令"
  die "请手动在 LuCI 系统→计划任务 添加: $KEEP_LINE 与 $CRON_LINE"
fi

say "=== 7/7 完成 ==="
cat <<EOF

路径一览
  脚本目录   $SC
  网页凭据   $WB/checkin-cred.json  (600)
  令牌文件   $WB/checkin-rt.json    (600，备用通道)
  运行日志   $SC/checkin.log / $SC/cookie_keep.log
  时区       $(date '+%Z %z')  ← cron 的 $START_HOUR 点按此计算

常用命令
  凭据体检   $PY $SC/cookie_keep.py --status
  只读检查   $PY $SC/auto_checkin.py --web --check-only --no-notify
  手动签到   $PY $SC/auto_checkin.py --web
  重新授权   $PY $SC/web_auth.py --setup-curl -
  查看日志   tail -n 40 $SC/checkin.log；tail -n 20 $SC/cookie_keep.log
  查看任务   crontab -l
  停用任务   crontab -e  (删除两行)
EOF
